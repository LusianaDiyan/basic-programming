#include <stdio.h> 

void main (){
	printf("1\n");
	printf("2\n");
}